module;

#include <SDL3/SDL.h>

export module Tick_Render;

import Create_New_Pipeline;

export void tickRender(){
    drawFrame();
}