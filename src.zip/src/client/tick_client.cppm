module;
export module Tick_Client;

import Tick_Render;

export void tickClient(){
    tickRender();
}